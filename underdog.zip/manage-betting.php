<?php
session_start();
include('db.php');

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Underdog -- App Management Sys</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/jquery.bxslider.css" rel="stylesheet">
	<link href="css/responsiveslides.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
<header class="innerpage-header">
		<?php include('innerpage_header_admin.php'); ?>
	</header>
	
	
	<section class="inner-menu-admin">
		<?php include('inner_menu_admin.php');  ?>
	</section>
	
	<section class="tab-content-space">
		<div class="row">
			<div class="col-lg-12">
				<div class="form-label-head">Betting Management</div>
				<div class="form-box">
					<div class="top-search-bar clearfix">
						<div class="col-lg-6 text-left">
							<form class="form-inline" role="form">
								<div class="form-group small-width-admin">
								  <select class="form-control" id="sel1">
									<option>A</option>
									<option>B</option>
									<option>C</option>
									<option>4</option>
								  </select>
								</div>
								<div class="input-group">
								  <input type="text" class="form-control" placeholder="Search for...">
								  <span class="input-group-btn">
									<button class="btn btn-danger" type="button"><i class="fa fa-search" aria-hidden="true"></i></button>
								  </span>
								</div>
							</form>
						</div>
						<div class="col-lg-6 text-right">
							<button type="button" class="btn btn-success" data-toggle="modal" data-target="#live-match"><i class="fa fa-eye" aria-hidden="true"></i> Live Match</button>
						</div>
					</div>
					
					<div class="betting-table table-responsive">
						 <table class="table borderless">
							<thead>
							  <tr>
								<th>Team Name</th>
								<th>Goal Spread</th>
								<th>Moneyline</th>
								<th>Total Goals</th>
							  </tr>
							</thead>
							<tbody>
							  <tr>
								<td>Cincinnati Bengals </td>
								<td class="link-show"><button class="btn">+9 (-120)</button></td>
								<td class="link-show"><button class="btn">+330</button></td>
								<td class="link-show"><button class="btn"><span class="pull-left">Over</span> 2 (-130)</button></td>
							  </tr>
							  <tr>
								<td>Indianapolis Colts</td>
								<td class="link-show"><button class="btn">+9 (-120)</button></td>
								<td class="link-show"><button class="btn">+330</button></td>
								<td class="link-show"><button class="btn"><span class="pull-left">Even</span> 2 (-130)</button></td>
							  </tr>
							</tbody>
						  </table>
					</div>
					
				</div>
			</div>
			
			<div class="col-lg-12">
				<div class="form-label-head">Live Betting</div>
				<div class="form-box">
					<div class="lobby-table table-responsive">
						 <table class="table borderless lobby table-hover">
							<thead>
							  <tr>
								<th>League Name</th>
								<th>Entries</th>
								<th>Size</th>
								<th>Entry</th>
								<th>Prizes</th>
								<th>Start</th>
								<th></th>
							  </tr>
							</thead>
							<tbody>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$3M NFL Sunday Million</a></td>
								<td>1377</td>
								<td>13793</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$3M NFL Sunday Million</a></td>
								<td>10</td>
								<td>2777</td>
								<td>$200</td>
								<td>$5,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$12K NFL Bitz</a></td>
								<td>128</td>
								<td>11498</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$12K NFL Bomb</a></td>
								<td>84</td>
								<td>13793</td>
								<td>$5</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$10K NFL Punt</a></td>
								<td>1377</td>
								<td>13793</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$6K NFL Touchdown</a></td>
								<td>1377</td>
								<td>13793</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$3M NFL Sunday Million</a></td>
								<td>1377</td>
								<td>13793</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$3M NFL Sunday Million</a></td>
								<td>10</td>
								<td>2777</td>
								<td>$200</td>
								<td>$5,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$12K NFL Bitz</a></td>
								<td>128</td>
								<td>11498</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$12K NFL Bomb</a></td>
								<td>84</td>
								<td>13793</td>
								<td>$5</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$10K NFL Punt</a></td>
								<td>1377</td>
								<td>13793</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.html">$6K NFL Touchdown</a></td>
								<td>1377</td>
								<td>13793</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="live-betting.html" class="btn-com">Enter</a></td>
							  </tr>
							</tbody>
						  </table>
					</div>
				</div>
			</div>
			
			
		</div>
	<section>
	
	
	

	
	<footer class="admin">
		<?php include('footer_admin.php'); ?>
	</footer>
	
	
	<!-- Live Match Modal -->
	  <div class="modal fade" id="live-match" role="dialog">
		<div class="modal-dialog">
		
		  <!-- Modal content-->
		  <div class="modal-content">
			<div class="modal-header alert-danger">
			  <button type="button" class="close" data-dismiss="modal">&times;</button>
			  <h4 class="modal-title">Live Match</h4>
			</div>
			<div class="modal-body" style="padding:0px;">
			    <div class="row betting-bg">
					<div class="col-lg-4 col-md-3 col-sm-3">
						<div class="small-size">
							<div class="team-name"><img src="team-img/cin-logo.png" alt="">Cincinnati Bengals</div>
							<div class="score">0</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6 col-sm-6">
						<div class="match-details">
							<div class="time" id="timer"></div>
							<div class="clearfix"><span class="pull-left redcard">1</span><span class="cards-pen">RED CARDS</span><span class="pull-right redcard">0</span></div>
							<div class="clearfix"><span class="pull-left yellowcard">0</span><span class="cards-pen">Yellow CARDS</span><span class="pull-right yellowcard">0</span></div>
							<div class="clearfix"><span class="pull-left corner">0</span><span class="cards-pen">Corners</span><span class="pull-right corner">0</span></div>
						</div>
					</div>
					<div class="col-lg-4 col-md-3 col-sm-3">
						<div class="small-size">
							<div class="team-name"><img src="team-img/colt-logo.png" alt="">Indianapolis Colts</div>
							<div class="score">1</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
			  
			</div>
		  </div>
		  
		</div>
	  </div>
	  
	
	  
	  
	
	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.bxslider.js"></script>
	
	<script src="js/responsiveslides.js"></script>
	<script>
		$('.bxslider').bxSlider({
		  mode: 'vertical',
		  auto: true,
		  slideMargin: 5,
		  pager:false
		});
	</script>
	<script>
	  $(function() {
		$(".rslides").responsiveSlides();
		
		document.getElementById('timer').innerHTML =
		  30 + ":" + 00;
		startTimer();

		function startTimer() {
		  var presentTime = document.getElementById('timer').innerHTML;
		  var timeArray = presentTime.split(/[:]+/);
		  var m = timeArray[0];
		  var s = checkSecond((timeArray[1] - 1));
		  if(s==59){m=m-1}
		  //if(m<0){alert('timer completed')}
		  
		  document.getElementById('timer').innerHTML =
			m + ":" + s;
		  setTimeout(startTimer, 1000);
		}

		function checkSecond(sec) {
		  if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
		  if (sec < 0) {sec = "59"};
		  return sec;
		}
	  });
	</script>
  </body>
</html>