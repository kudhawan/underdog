<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>:: NFL :: Online Football Betting by Underdog</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/jquery.bxslider.css" rel="stylesheet">
	<link href="css/responsiveslides.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	
	
	<header class="header-main">
		<div class="top-nav-bar">
			<div class="container">
				<div class="col-lg-12 text-right">
					<ul class="top-nav-links">
						<li><a href="#" target="_blank"><span class="fa fa-facebook"></span></a> <a href="#" target="_blank"><span class="fa fa-twitter"></span></a> <a href="#" target="_blank"><span class="fa fa-pinterest-p"></span></a> <a href="#" target="_blank"><span class="fa fa-instagram"></span></a></li>
						<li><a href="#">Contact</a></li>
						<li><a href="admin-login.php"><span class="fa fa-lock"></span> Admin Login</a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="container">
			<nav class="navbar" role="navigation">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				  
				</div>
				<!--<a class="navbar-brand" href="index.php">
					
				</a>-->
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="navbar-collapse-1">
				 
				  <ul class="nav navbar-nav  custom-menu">
					<!--<li><a href="#">News</a></li>
					<li><a href="#">Team</a></li>
					<li><a href="#">Match Result</a></li>-->
					<li><a href="#">Live Betting</a></li>
					<li><a href="register.php">League Leader Signup</a></li>
					<li><a href="javascript:void(0);" data-toggle="modal" data-target="#myModal">Login</a></li>
					<li><a href="#">Underdog</a></li>
				  </ul>
				</div><!-- /.navbar-collapse -->
			</nav>
		</div>
	</header>
  
	<section class="banner">
		<ul class="rslides">
		  <li><img src="images/popular_video_banner1.jpg" alt=""></li>
		  <li><img src="images/popular_video_banner.jpg" alt=""></li>
		</ul>
	</section>
  
	<section class="top-headlines">
		<div class="container">
			<div class="col-lg-12 clearfix">
				<div class="top-headlines-ani"><span class="fa fa-dot-circle-o animated pulse infinite"></span> Top Headlines :</div>
				<div class="news-content">
					<ul class="bxslider">
						<li>DeShone Kizer got the somewhat surprising nod to start at quarterback for the Browns in Week 3. </li>
						<li>Jamaal Charles hasn't taken a meaningful, early season snap in what seems like forever.</li>
						<li>The Texans are heading to Dallas due to flooding in the Houston area, according to NFL Network Insider </li>
						<li>For a moment on Saturday, there were fears Paxton Lynch might have lost some future availability. </li>
					</ul>
				</div>
				<div class="view-all"><a href="#">Readmore<span class="fa fa-angle-double-right"></span></a></div>
			</div>
		</div>
	</section>
	
	<section class="upcoming-matches">
		<div class="container">
			<div class="col-lg-2 col-md-2 upcom">
				<h3>Next <br>PRE - SEASON <span class="fa fa-flag-checkered"></span></h3>
			</div>
			<div class="col-lg-8 col-md-8">
				<div class="col-lg-12 next-title">Next Game</div>
				<div class="col-lg-4 col-md-3 col-sm-4 text-center">
					<div class="left-team">
						<img src="team-img/cin-logo.png" alt="">
						<p>Cincinnati Bengals</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-4 text-center">
					<div class="match-sheducle">
						<div><span class="fa fa-at"></span></div>
						<div class="label-sheducle">
							<p><span class="fa fa-calendar-o"></span>THURSDAY, AUG 31ST </p>
							<p><span class="fa fa-clock-o"></span>7:00 PM  ET</p>
							<p><span class="fa fa-map-marker"></span>LUCAS OIL STADIUM</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-3 col-sm-4 text-center">
					<div class="right-team">
						<img src="team-img/colt-logo.png" alt="">
						<p>Indianapolis Colts</p>
					</div>
				</div>
				<div class="col-lg-12 next-title">Next PRE-SEASON</div>
			</div>
			<div class="col-lg-2 col-md-2 text-right upcom">
				<h3><a href="#">Start <br>Bet Now</a></h3>
			</div>
		</div>
	</section>
    
	<section class="content-part">
		<div class="container">
			<div class="col-lg-5 col-md-6">
				<div class="about-underdog">
					<h2 class="line-light">Welcome to Underdog Online Betting</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
					<button class="btn btn-secondary customs-btn">Viewmore</button>
				</div>
			</div>
			
			<div class="col-lg-7 col-md-6">
				<div class="game-list">
					<div class="part-a clearfix">
						<div class="team-logo-left pull-left vs"><img src="team-img/Jacksonville_Jaguars_logo.png" class="hidden-logo" alt=""> <span>Jacksonville Jaguars</span></div>
						<div class="team-logo-right pull-right"><span>Philadelphia Eagles</span><img src="team-img/Philadelphia_Eagles_primary_logo.png" class="hidden-logo" alt=""> </div>
					</div>
					<div class="part-b clearfix">
						<div class="team-logo-left pull-left">SUNDAY, AUG 27TH 1:00 PM  ET,<br> NISSAN STADIUM</div>
						<div class="team-logo-right pull-right"><button class="btn btn-secondary customs-btn">Bet Now / Ticket</button></div>
					</div>
				</div>
				<div class="game-list">
					<div class="part-a clearfix">
						<div class="team-logo-left pull-left vs"><img src="team-img/Atlanta_Falcons_logo.png" class="hidden-logo" alt=""> <span>Atlanta Falcons</span></div>
						<div class="team-logo-right pull-right"><span>New York Jets</span><img src="team-img/New_York_Jets_logo.png" class="hidden-logo" alt=""> </div>
					</div>
					<div class="part-b clearfix">
						<div class="team-logo-left pull-left">SUNDAY, AUG 27TH 1:00 PM  ET,<br> NISSAN STADIUM</div>
						<div class="team-logo-right pull-right"><button class="btn btn-secondary customs-btn">Bet Now / Ticket</button></div>
					</div>
				</div>
				<div class="game-list">
					<div class="part-a clearfix">
						<div class="team-logo-left pull-left vs"><img src="team-img/Jacksonville_Jaguars_logo.png" class="hidden-logo" alt=""> <span>Jacksonville Jaguars</span></div>
						<div class="team-logo-right pull-right"><span>Philadelphia Eagles</span><img src="team-img/Philadelphia_Eagles_primary_logo.png" class="hidden-logo" alt=""> </div>
					</div>
					<div class="part-b clearfix">
						<div class="team-logo-left pull-left">SUNDAY, AUG 27TH 1:00 PM  ET,<br> NISSAN STADIUM</div>
						<div class="team-logo-right pull-right"><button class="btn btn-secondary customs-btn">Bet Now / Ticket</button></div>
					</div>
				</div>
				<div class="game-list">
					<div class="part-a clearfix">
						<div class="team-logo-left pull-left vs"><img src="team-img/Atlanta_Falcons_logo.png" class="hidden-logo" alt=""> <span>Atlanta Falcons</span></div>
						<div class="team-logo-right pull-right"><span>New York Jets</span><img src="team-img/New_York_Jets_logo.png" class="hidden-logo" alt=""> </div>
					</div>
					<div class="part-b clearfix">
						<div class="team-logo-left pull-left">SUNDAY, AUG 27TH 1:00 PM  ET,<br> NISSAN STADIUM</div>
						<div class="team-logo-right pull-right"><button class="btn btn-secondary customs-btn">Bet Now / Ticket</button></div>
					</div>
				</div>
			</div>
			
		</div>
	</section>
	
	<footer>
		<div class="container">
			<div class="col-lg-4 col-md-4">
				<div class="contact-details">
					<div class="footer-logo"><a href="#"><img src="images/logo-footer.png" alt=""></a></div>
					<div class="address-detail">
						<p><span class="fa fa-map-marker"></span> 10187 104 St NW, Edmonton, AB T5J 0Z9</p>
						<p><span class="fa fa-mobile"></span> +1 379-226-1326</p>
						<p><span class="fa fa-envelope-o"></span> <a href="mailto:info@underdog.us" target="_blank">info@underdog.us</a></p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4">
				<div class="quick-links clearfix">
					<h3>QUICK LINKS</h3>
					<ul class="pull-left">
						<li><span class="fa fa-dot-circle-o"></span><a href="#">About Underdog</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">NFL Teams</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Betting</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">News</a></i>
					</ul>
					<ul class="pull-right">
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Payments</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Privacy Policy</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Terms &amp; Conditions</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Blog</a></i>
					</ul>
				</div>
			</div>
			<div class="col-lg-4 col-md-4">
				<div class="newsletters">
					<h3>SIGN UP FOR LEAGUE ALERTS</h3>
					<p>Select topics and stay current with our latest news.</p>
					<div class="input-group">
					  <input type="text" class="form-control footer-inputs-customs" placeholder="Your email address">
					  <span class="input-group-btn">
						<button class="btn btn-secondary customs-btn" type="button">SUBMIT</button>
					  </span>
					</div>
				</div>
			</div>
		</div>
		<div class="container copy-rights">
			<div class="col-lg-4 col-md-4">
				<div class="copy-text text-left small-d">Copyright &copy; 2017 <a href="#">Underdog</a> All rights reserved</div>
			</div>
			<div class="col-lg-4 col-md-4">
				<div class="copy-text text-center">
					<ul class="social-links">
						<li><a href="#" target="_blank"><span class="fa fa-facebook"></span></a> </li>
						<li><a href="#" target="_blank"><span class="fa fa-twitter"></span></a></li>
						<li><a href="#" target="_blank"><span class="fa fa-pinterest-p"></span></a></li>
						<li><a href="#" target="_blank"><span class="fa fa-instagram"></span></a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-4 col-md-4">
				<div class="copy-text text-right small-d">designed and developed at <a href="#">Alberta TechWorks</a></div>
			</div>
		</div>
	</footer>
	
	
	<!-- Login Modal  -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<a class="close" data-dismiss="modal" aria-label="Close"><span class="fa fa-window-close-o" aria-hidden="true"></span></a>
			
		  </div>
		  <div class="modal-body" >
			<h2 class="text-center">Welcome to Underdog !</h2>
             <p align="center" id="error_msg" class="alert_msg"></p>
             
			<form class="form-login" action="" method="post" id="login_form">
				<label><input type="text" name="username" id="username" value="" placeholder="Username" class="validation_chk"></label>
				<label><input type="password" name="password" id="password" value="" placeholder="Password" class="validation_chk"></label>
				<label><button type="button" name="login" id="login" class="btn btn-secondary customs-btn">Login</button></label>
			</form>
		  </div>
		  <div class="modal-footer">
			<p><a href="javascript:void(0);" data-toggle="modal" data-target="#myModal1">Forgot password?</a></p>
			<p>Not a member? <a href="register.php">Join today</a></p>
		  </div>
		</div>
	  </div>
	</div>
	
	<!-- Forgot Password Modal  -->
	<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<a class="close" data-dismiss="modal" aria-label="Close"><span class="fa fa-window-close-o" aria-hidden="true"></span></a>
			
		  </div>
		  <div class="modal-body">
			<h2 class="text-center">Forgot your login detail?</h2>
             <p id="alert_msg_forgot" align="center" class="alert_msg" ></p>
			<form class="form-login" id="forgot_form">
				<label><input type="email" name="email_forgot" id="email_forgot" value="" placeholder="Enter your Email Address"></label>
                 <span id="email_errorMsg_forgot" align="center" class="error_msg"></span>
				<label><button type="button" name="forgot" id="forgot" class="btn btn-secondary customs-btn">Continue</button></label>
			</form>
		  </div>
		  <div class="modal-footer">
			<p><a href="javascript:void(0);" data-toggle="modal" data-target="#myModal">Back to Login</a></p>
			<p>Not a member? <a href="register.html">Join today</a></p>
		  </div>
		</div>
	  </div>
	</div>
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.bxslider.js"></script>
	
	<script src="js/responsiveslides.js"></script>
	<script>
		$('.bxslider').bxSlider({
		  mode: 'vertical',
		  auto: true,
		  slideMargin: 5,
		  pager:false
		});
	</script>
	<script>
	  $(function() {
		$(".rslides").responsiveSlides();
	  });
	  /*clearing all validation msgs/error msgs on page load */
	  
	  $(".validation_chk").val('');
	  
	  /*Removing validation on element keyup event*/
	  $(".validation_chk").keyup(function(){
		if(this.value!='')
		{
			$(this).css("border","");
		}
	
	 });	
	 /*Login form script -  validation check/login check*/ 
	  $("#login").click(function(){
		var validation_chk=$('.validation_chk').val();
		if(validation_chk=='')
		{
			$('.validation_chk').css("border-color","red");
			return false;
		}
		
		
		var username=$('#username').val();
		var password=$('#password').val();
		
		
		if(username=='')
		{
			$('#username').focus();
			$('#username').css("border-color","red");
			return false;
		}
		
		else if(password=='')
		{
			$('#password').focus();
			$('#password').css("border-color","red");
			return false;
		}
		
		
		else
		{
		 $.ajax({
				type: "POST",
				url: "ajaxfunctions.php?login",
				data: $('#login_form').serialize(),
				success: function(data) {
					 //alert(data);
					if(data=='success')
					{
						window.location.href='lobby.php';	
					}
					else if(data=='Invalid Username')
					{
						$('#error_msg').html(data);
						$("#username").val('');
						$("#password").val('');
					}
					else if(data=='Invalid Password')
					{
						$('#error_msg').html(data);
						$("#username").val(username);
						$("#password").val('');
					}
					else
					{
						$('#error_msg').html(data);
						$("#username,#password").val('');
					}
				}
		 });
		 
		}
	 });
	 /* forgot password script*/
	 $("#email_forgot").keyup(function(){
		if(this.value!='')
		{
			$(this).css("border","");
		}
	
	});	
	$("#email_forgot").blur(function(){
		 var email_forgot=this.value;
		 var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		 if(email_forgot=='')
			{
				$('#email_forgot').focus();
				$('#email_forgot').css("border-color","red");
				return false;
			}
			else if ( !emailReg.test( email_forgot ) ) {
				$('#email_forgot').focus();
				$('#email_forgot').css("border-color","red");
				return false;
			}
			else
			{
				$(this).css("border","");
			}
	
	});	
	
	
	$('#email_errorMsg_forgot').hide();
	$("#forgot").click(function(){
		
		var email_forgot=$('#email_forgot').val();
		var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		
		if(email_forgot=='')
		{
			$('#email_forgot').focus();
			$('#email_forgot').css("border-color","red");
			return false;
		}
		else if ( !emailReg.test( email_forgot ) ) {
            $('#email_forgot').focus();
			$('#email_forgot').css("border-color","red");
			$('#email_errorMsg_forgot').html('Please enter a valid email address').modal();
			return false;
        }
		
		else
		{
			$('#email_errorMsg_forgot').html('').modal();
		    $.ajax({
				type: "POST",
				url: "ajaxfunctions.php?forgot",
				data: $('#forgot_form').serialize(),
				success: function(data) {
					// alert(data);
					if(data=='success')
					{
						//window.location.href='email_confirmation.php';	
						$('#alert_msg_forgot').html(data).modal();
						
					}
					else
					{
						$('#alert_msg_forgot').html(data).modal();
						$('#email_forgot').val('');
						
					}
				}
		     });
		 
		}
	 });
	</script>
  </body>
</html>