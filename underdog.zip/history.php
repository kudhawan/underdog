<?php
session_start();
include('db.php');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>:: NFL :: Online Football Betting by Underdog</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/jquery.bxslider.css" rel="stylesheet">
	<link href="css/responsiveslides.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	
<header class="innerpage-header">
		<?php include('innerpage_header.php'); ?>
	</header>
	
	<section class="inner-menu">
		<?php include('inner_menu.php');  ?>
	</section>
	
	
	<section class="tab-content-space">
		<div class="row">
			<div class="col-lg-12">
				<div class="form-label-head">Entry History</div>
				<div class="form-box">
					<div class="lobby-table table-responsive">
						<table class="table borderless lobby table-striped">
							<thead>
							  <tr>
								<th>ID</th>
								<th>Date</th>
								<th>Contest</th>
								<th>Cap</th>
								<th>Score</th>
								<th>Opponent</th>
								<th>Entry Fees</th>
								<th>Winnings</th>
								<th></th>
							  </tr>
							</thead>
							<tbody>
							  <tr>
								<td>S17658</td>
								<td>5/9/2017</td>
								<td><span class="fa fa-futbol-o"></span> <a href="#">$3M NFL Sunday Million</a></td>
								<td>$66K</td>
								<td>1148.29 (17 of 50)</td>
								<td>50 Player League</td>
								<td>$5</td>
								<td>$0</td>
								<td><a href="#" class="btn-com">View Now</a></td>
							  </tr>
							  <tr>
								<td>S17658</td>
								<td>5/9/2017</td>
								<td><span class="fa fa-futbol-o"></span> <a href="#">$3M NFL Sunday Million</a></td>
								<td>$66K</td>
								<td>1148.29 (17 of 50)</td>
								<td>50 Player League</td>
								<td>$5</td>
								<td>$55</td>
								<td><a href="#" class="btn-com">View Now</a></td>
							  </tr>
							  <tr>
								<td>S17658</td>
								<td>5/9/2017</td>
								<td><span class="fa fa-futbol-o"></span> <a href="#">$3M NFL Sunday Million</a></td>
								<td>$66K</td>
								<td>1148.29 (17 of 50)</td>
								<td>50 Player League</td>
								<td>$5</td>
								<td>$55</td>
								<td><a href="#" class="btn-com">View Now</a></td>
							  </tr>
							  <tr>
								<td>S17658</td>
								<td>5/9/2017</td>
								<td><span class="fa fa-futbol-o"></span> <a href="#">$3M NFL Sunday Million</a></td>
								<td>$66K</td>
								<td>1148.29 (17 of 50)</td>
								<td>50 Player League</td>
								<td>$5</td>
								<td>$55</td>
								<td><a href="#" class="btn-com">View Now</a></td>
							  </tr>
							  <tr>
								<td>S17658</td>
								<td>5/9/2017</td>
								<td><span class="fa fa-futbol-o"></span> <a href="#">$3M NFL Sunday Million</a></td>
								<td>$66K</td>
								<td>1148.29 (17 of 50)</td>
								<td>50 Player League</td>
								<td>$5</td>
								<td>$55</td>
								<td><a href="#" class="btn-com">View Now</a></td>
							  </tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	<section>
	
    <footer>
		<?php include('footer.php'); ?>
	</footer>	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.bxslider.js"></script>
	
	<script src="js/responsiveslides.js"></script>
	<script>
		$('.bxslider').bxSlider({
		  mode: 'vertical',
		  auto: true,
		  slideMargin: 5,
		  pager:false
		});
	</script>
	<script>
	  $(function() {
		$(".rslides").responsiveSlides();
	  });
	</script>
  </body>
</html>