<?php
session_start();
include('db.php');
$login_type=$_SESSION['login_type'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>:: NFL :: Online Football Betting by Underdog</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/jquery.bxslider.css" rel="stylesheet">
	<link href="css/responsiveslides.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	
	<header class="innerpage-header">
		<?php 
			if($login_type==1){
				include('innerpage_header.php');
			}
			else if($login_type==2)
			{
				include('innerpage_header_admin.php');
			}
		?>
	</header>
	
	<section class="inner-menu">
       <?php 
			if($login_type==1){
				include('inner_menu.php');
			}
			else if($login_type==2)
			{
				include('inner_menu_admin.php');
			}
		?>
        
	</section>
	
	
	<section class="tab-content-space">
		<div class="row">
			<div class="col-lg-6 col-md-6">
				<div class="left-sidebar">
					<div class="form-label-head">Matches</div>
					<div class="form-box">
						<ul class="match-table">
							<li>
								<div class="match-name">Cincinnati Bengals <span>vs</span> Indianapolis Colts</div>
								<p>Running: <span class="fa fa-dot-circle-o"></span>0 -1 </p>
							</li>
							<li>
								<div class="match-name">Jacksonville Jaguars<span>vs</span> Philadelphia Eagles</div>
								<p><span class="fa fa-dot-circle-o"></span>4:00a Starts in 1h 36m</p>
							</li>
							<li>
								<div class="match-name">Atlanta Falcons<span>vs</span> New York Jets</div>
								<p><span class="fa fa-dot-circle-o"></span>4:00a Starts in 1h 36m</p>
							</li>
						</ul>
					</div>
					<div class="form-label-head top-space">Next Season's</div>
					<div class="form-box">
						<ul class="match-table">
							<li>
								<div class="match-name">Cincinnati Bengals <span>vs</span> Indianapolis Colts</div>
								<p>Running: <span class="fa fa-dot-circle-o"></span>0 -1 </p>
							</li>
							<li>
								<div class="match-name">Jacksonville Jaguars<span>vs</span> Philadelphia Eagles</div>
								<p><span class="fa fa-dot-circle-o"></span>4:00a Starts in 1h 36m</p>
							</li>
							<li>
								<div class="match-name">Atlanta Falcons<span>vs</span> New York Jets</div>
								<p><span class="fa fa-dot-circle-o"></span>4:00a Starts in 1h 36m</p>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 padding-remove">
				<div class="row betting-bg">
					<div class="col-lg-4 col-md-3 col-sm-3">
						<div class="small-size">
							<div class="team-name"><img src="team-img/cin-logo.png" alt="">Cincinnati Bengals</div>
							<div class="score">0</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6 col-sm-6">
						<div class="match-details">
							<div class="time" id="timer"></div>
							<div class="clearfix"><span class="pull-left redcard">1</span><span class="cards-pen">RED CARDS</span><span class="pull-right redcard">0</span></div>
							<div class="clearfix"><span class="pull-left yellowcard">0</span><span class="cards-pen">Yellow CARDS</span><span class="pull-right yellowcard">0</span></div>
							<div class="clearfix"><span class="pull-left corner">0</span><span class="cards-pen">Corners</span><span class="pull-right corner">0</span></div>
						</div>
					</div>
					<div class="col-lg-4 col-md-3 col-sm-3">
						<div class="small-size">
							<div class="team-name"><img src="team-img/colt-logo.png" alt="">Indianapolis Colts</div>
							<div class="score">1</div>
						</div>
					</div>
					<div class="col-lg-12">
						<div class="matches-bar">
							<ul class="bxslider">
								<li>Game Started</li>
								<li>Cincinnati Bengals Wins 1</li>
								<li>Indianapolis Colts in Corner 1</li>
								<li>XYZ</li>
							</ul>
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="form-box">
						<div class="betting-table table-responsive">
							 <table class="table borderless">
								<thead>
								  <tr>
									<th>Team Name</th>
									<th>Goal Spread</th>
									<th>Moneyline</th>
									<th>Total Goals</th>
								  </tr>
								</thead>
								<tbody>
								  <tr>
									<td>Cincinnati Bengals </td>
									<td class="link-show"><button class="btn">+9 (-120)</button></td>
									<td class="link-show"><button class="btn">+330</button></td>
									<td class="link-show"><button class="btn"><span class="pull-left">Over</span> 2 (-130)</button></td>
								  </tr>
								  <tr>
									<td>Indianapolis Colts</td>
									<td class="link-show"><button class="btn">+9 (-120)</button></td>
									<td class="link-show"><button class="btn">+330</button></td>
									<td class="link-show"><button class="btn"><span class="pull-left">Even</span> 2 (-130)</button></td>
								  </tr>
								</tbody>
							  </table>
						</div>
						<div class="betting-table">
							 <table class="table borderless">
								<thead>
								  <tr>
									<th colspan="4">NEXT TEAM TO SCORE (5TH) GOAL IN MATCH</th>
								  </tr>
								</thead>
								<tbody>
								  <tr>
									<td>Cincinnati Bengals </td>
									<td><button class="btn">+9 (-120)</button></td>
									<td><button class="btn">+330</button></td>
									<td><button class="btn"><span class="pull-left">Over</span> 2 (-130)</button></td>
								  </tr>
								</tbody>
							  </table>
						</div>
					</div>
				</div>
				
			</div>
			<!--<div class="col-lg-3 col-md-3">
				<div class="right-sidebar">
					<div class="form-label-head">Bet Slip</div>
					<div class="form-box betslip">
						<p><span class="fa fa-hand-o-down"></span> Start Betting</p>
						<p>Please add selections to your Bet Slip.</p>
						<div class="betslip-table" style="display:none;">
							<table class="table borderless table-striped">
								<thead>
									<tr>
										<th colspan="2">Cincinnati Bengals <span class="fa fa-window-close pull-right"></span></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td colspan="2">7:00 PM ET, Lucas Oil Stadium</td>
									</tr>
									<tr>
										<td colspan="2">Goal Spread</td>
									</tr>
									<tr>
										<td>Bet :<input type="text" value="0"></td>
										<td>To Win :<input type="text" value="0"></td>
									</tr>
								</tbody>
								<tfoot>
									<tr>
										<td>Total Stake:</td>
										<td class="text-right">$0.00</td>
									</tr>
									<tr>
										<td>Total Win:</td>
										<td class="text-right">$0.00</td>
									</tr>
								</tfoot>
							</table>
						</div>
						<div><button class="btn btn-secondary customs-btn full-width">Place Bets</button></div>
					</div>
					
				</div>
			</div> -->
		</div>
	<section>
	
	
	

	
	<footer>
       <?php 
			if($login_type==1){
				include('footer.php');
			}
			else if($login_type==2)
			{
				include('footer_admin.php');
			}
		?>
        
	</footer>
	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.bxslider.js"></script>
	
	<script src="js/responsiveslides.js"></script>
	<script>
		$('.bxslider').bxSlider({
		  mode: 'vertical',
		  auto: true,
		  slideMargin: 5,
		  pager:false
		});
		
		$(".link-show").click(function(){
			$(".betslip-table").css("display","block");
			$(".betslip  p").css("display","none");
		});
	</script>
	<script>
	  $(function() {
		$(".rslides").responsiveSlides();
	  });
	  
	  document.getElementById('timer').innerHTML =
		  30 + ":" + 00;
		startTimer();

		function startTimer() {
		  var presentTime = document.getElementById('timer').innerHTML;
		  var timeArray = presentTime.split(/[:]+/);
		  var m = timeArray[0];
		  var s = checkSecond((timeArray[1] - 1));
		  if(s==59){m=m-1}
		  //if(m<0){alert('timer completed')}
		  
		  document.getElementById('timer').innerHTML =
			m + ":" + s;
		  setTimeout(startTimer, 1000);
		}

		function checkSecond(sec) {
		  if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
		  if (sec < 0) {sec = "59"};
		  return sec;
		}
	</script>
  </body>
</html>