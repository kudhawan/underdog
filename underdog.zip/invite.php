<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>:: NFL :: Online Football Betting by Underdog</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/jquery.bxslider.css" rel="stylesheet">
	<link href="css/responsiveslides.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	
	<header class="innerpage-header">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-2">
				<div class="inner-logo"><a href="lobby.html"><img src="images/logo-footer.png" alt=""></a></div>
			</div>
			<div class="col-lg-8 col-md-8 col-sm-10 text-right">
				<ul class="top-inner-navbar">
					<li>Steve Austin <a href="index.html">[Logout]</a></li>
					<li>Balance: $25.00</li>
					<li><a href="#" class="btn-com">ADD CASH</a></li>
					<li><a href="invite.html" class="btn-com-red">Invite Friend's</a></li>
				</ul>
			</div>
		</div>
	</header>
	
	
	
	
  
	
	<section class="inner-content">
		<div class="row">
			<h3 class="text-center black">Invite Friends. Get Premium for Free.</h3>
			<form class="register-form">
				<div class="form-label-head">Get Contacts</div>
				<div class="form-box">
					<p><span class="fa fa-smile-o"></span></p>
					<h3 class="text-center black">Invite your contacts from your Address Book</h3>
					<p><button class="btn facebook"><span class="fa fa-facebook-official"></span> Facebook</button><button class="btn gmail"><span class="fa fa-envelope"></span> Gmail</button><button class="btn twitter"><span class="fa fa-twitter-square"></span> Twitter</button></p>
					<p class="text-center"><input type="text" value="" placeholder="Email address"></p>
					<p class="text-center"><button class="btn btn-secondary customs-btn">Send Invitation</button></p>
				</div>
			</form>
		</div>
	</section>
	

	
	<footer>
		<div class="container">
			<div class="col-lg-4 col-md-4">
				<div class="contact-details">
					<div class="footer-logo"><a href="#"><img src="images/logo-footer.png" alt=""></a></div>
					<div class="address-detail">
						<p><span class="fa fa-map-marker"></span> 10187 104 St NW, Edmonton, AB T5J 0Z9</p>
						<p><span class="fa fa-mobile"></span> +1 379-226-1326</p>
						<p><span class="fa fa-envelope-o"></span> <a href="mailto:info@underdog.us" target="_blank">info@underdog.us</a></p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4">
				<div class="quick-links clearfix">
					<h3>QUICK LINKS</h3>
					<ul class="pull-left">
						<li><span class="fa fa-dot-circle-o"></span><a href="#">About Underdog</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">NFL Teams</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Betting</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">News</a></i>
					</ul>
					<ul class="pull-right">
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Payments</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Privacy Policy</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Terms &amp; Conditions</a></i>
						<li><span class="fa fa-dot-circle-o"></span><a href="#">Blog</a></i>
					</ul>
				</div>
			</div>
			<div class="col-lg-4 col-md-4">
				<div class="newsletters">
					<h3>SIGN UP FOR LEAGUE ALERTS</h3>
					<p>Select topics and stay current with our latest news.</p>
					<div class="input-group">
					  <input type="text" class="form-control footer-inputs-customs" placeholder="Your email address">
					  <span class="input-group-btn">
						<button class="btn btn-secondary customs-btn" type="button">SUBMIT</button>
					  </span>
					</div>
				</div>
			</div>
		</div>
		<div class="container copy-rights">
			<div class="col-lg-4 col-md-4">
				<div class="copy-text text-left small-d">Copyright &copy; 2017 <a href="#">Underdog</a> All rights reserved</div>
			</div>
			<div class="col-lg-4 col-md-4">
				<div class="copy-text text-center">
					<ul class="social-links">
						<li><a href="#" target="_blank"><span class="fa fa-facebook"></span></a> </li>
						<li><a href="#" target="_blank"><span class="fa fa-twitter"></span></a></li>
						<li><a href="#" target="_blank"><span class="fa fa-pinterest-p"></span></a></li>
						<li><a href="#" target="_blank"><span class="fa fa-instagram"></span></a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-4 col-md-4">
				<div class="copy-text text-right small-d">designed and developed at <a href="#">Alberta TechWorks</a></div>
			</div>
		</div>
	</footer>
	
	
	
	
	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.bxslider.js"></script>
	
	<script src="js/responsiveslides.js"></script>
	<script>
		$('.bxslider').bxSlider({
		  mode: 'vertical',
		  auto: true,
		  slideMargin: 5,
		  pager:false
		});
	</script>
	<script>
	  $(function() {
		$(".rslides").responsiveSlides();
	  });
	</script>
  </body>
</html>