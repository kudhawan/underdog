<div class="row">
			<div class="col-lg-12">
				<ul class="nav nav-tabs">
					<li class="active"><a  href="lobby.php" >League</a></li>
					<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">My Contest <span class="caret"></span></a>
						<ul class="dropdown-menu cust-ex">
						  <li><a href="live-betting.php">Live Betting</a></li>
						  <li><a href="upcoming.php">Upcoming</a></li>
						  <li><a href="history.php">History</a></li> 
						</ul>
					</li>
					<li><a href="account.php">My Account</a></li>
					<!--<li><a data-toggle="tab" href="#promotions">Promotions</a></li>-->
				</ul>
			</div>
		</div>