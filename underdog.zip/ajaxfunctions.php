<?php
session_start();
include('db.php');
/*require 'PHPMailer/PHPMailerAutoload.php';
include 'PHPMailer/class.smtp.php';
require("PHPMailer/class.PHPMailer.php");*/

/**
     * Basic functions of the  application.
     *
     * - login - The login script for underdog app.
     * - signup - The Registration script for underdog app.
	  * - adminlogin - The Admin section login script for underdog app.
     
     */

/*Underdog Login script*/
if(isset($_GET['login']))
{
	$username=$_POST['username'];
	$password=base64_encode($_POST['password']);
	
	
	 $get=@mysql_query("select * from users where username='$username' and password='$password' and status=1 and login_type=1");
	 $num=@mysql_num_rows($get);
	 if($num>0)
	 {
		$dt=@mysql_fetch_array($get);
		  $_SESSION['first_name']=$dt['first_name'];
		  $_SESSION['last_name']=$dt['last_name'];
		  $_SESSION['user_id']=$dt['id'];
		  $_SESSION['email']=$dt['email'];
		  $_SESSION['login_type']=$dt['login_type'];
		
		 echo "success";
		 
	 }
	 else
	 {
		 $checkUsername=@mysql_query("select * from users where username='$username' and  status=1"); 
		 $numU=@mysql_num_rows($checkUsername);
		 $checkPassword=@mysql_query("select * from users where password='$password' and  status=1"); 
		 $numP=@mysql_num_rows($checkPassword);
		 
		 if($numU==0)
		 {
			echo "Invalid Username"; 
		 }
		 else if($numP==0)
		 {
			 echo "Invalid Password"; 
		 }
		 else
		 {
			 echo "Invalid username/password entered"; 
		 }
		 
		 
		 
		//echo "Failed"; 
	 }
	
	
}


if(isset($_GET['reglogin']))
{
	 $username=$_POST['login_username'];
	 $password=base64_encode($_POST['login_password']);
	
	
	 $get=@mysql_query("select * from users where username='$username' and password='$password' and status=1 and login_type=1");
	 $num=@mysql_num_rows($get);
	 if($num>0)
	 {
		$dt=@mysql_fetch_array($get);
		  $_SESSION['first_name']=$dt['first_name'];
		  $_SESSION['last_name']=$dt['last_name'];
		  $_SESSION['user_id']=$dt['id'];
		  $_SESSION['email']=$dt['email'];
		  $_SESSION['login_type']=$dt['login_type'];
		
		 echo "success";
		 
	 }
	 else
	 {
		 $checkUsername=@mysql_query("select * from users where username='$username' and  status=1"); 
		 $numU=@mysql_num_rows($checkUsername);
		 $checkPassword=@mysql_query("select * from users where password='$password' and  status=1"); 
		 $numP=@mysql_num_rows($checkPassword);
		 
		 if($numU==0)
		 {
			echo "Invalid Username"; 
		 }
		 else if($numP==0)
		 {
			 echo "Invalid Password"; 
		 }
		 else
		 {
			 echo "Invalid username/password entered"; 
		 }
		 
		 
		 
		//echo "Failed"; 
	 }
	
	
}
/*Admin login script*/
if(isset($_GET['adminlogin']))
{
	$username=$_POST['username'];
	$password=base64_encode($_POST['password']);
	
	
	 $get=@mysql_query("select * from users where username='$username' and password='$password' and status=1 and login_type=2");
	 $num=@mysql_num_rows($get);
	 if($num>0)
	 {
		$dt=@mysql_fetch_array($get);
		  $_SESSION['first_name']=$dt['first_name'];
		  $_SESSION['last_name']=$dt['last_name'];
		  $_SESSION['user_id']=$dt['id'];
		  $_SESSION['email']=$dt['email'];
		  $_SESSION['login_type']=$dt['login_type'];
		
		 echo "success";
		 
	 }
	 else
	 {
		 $checkUsername=@mysql_query("select * from users where username='$username' and  status=1 login_type=2"); 
		 $numU=@mysql_num_rows($checkUsername);
		 $checkPassword=@mysql_query("select * from users where password='$password' and  status=1 login_type=2"); 
		 $numP=@mysql_num_rows($checkPassword);
		 
		 if($numU==0)
		 {
			echo "Invalid Username"; 
		 }
		 else if($numP==0)
		 {
			 echo "Invalid Password"; 
		 }
		 else
		 {
			 echo "Invalid username/password entered"; 
		 }
		 
		 
		 
		//echo "Failed"; 
	 }
	
	
}


/*Underdog Registration script*/




if(isset($_GET['signup']))
{
    /*Declaring Post variables*/
    $first_name=$_POST['first_name'];
	$last_name=$_POST['last_name'];
	$username=$_POST['username'];
	$password=base64_encode($_POST['password']);
	$email=$_POST['email'];
	$middile_name='';
	$gender='';
	$dob='';
	$added_from='Underdog';
	$added_date=date("Y-m-d H:i:s");
    $status=1;
	$login_type=1;
	 
	 //$random_number=rand ( 10000 , 99999 );
	 
	$getEmail=@mysql_query("select * from users where email='$email' and status=1");
	$emailNum=@mysql_num_rows($getEmail);
	
	$getUser=@mysql_query("select * from users where username='$username' and status=1");
	$userNum=@mysql_num_rows($getUser);
	
	
	if(($emailNum==0)&&($userNum==0))
	{
		 $ins=@mysql_query("insert into users(`id`,`first_name`,`last_name`,`username`,`password`,`middile_name`,`gender`,`dob`,`email`,`added_from`,`added_date`,`status`,`login_type`) values('','".$first_name."','".$last_name."','".$username."','".$password."','".$middile_name."','".$gender."','".$dob."','".$email."','".$added_from."','".$added_date."','".$status."','".$login_type."')");
		   
		//$qry=@mysql_query($ins);
		 if($ins)
		 {
			 echo "success";
			 /*Creating session variables*/
			  $_SESSION['user_id']=@mysql_insert_id();
			  $_SESSION['first_name']=$first_name;
			  $_SESSION['last_name']=$last_name;
			  $_SESSION['email']=$email;
			  $_SESSION['login_type']=$login_type;
		 }
		 else
		 {
			echo  "Some thing went wrong.Please try again";
		 }
		
	}
	else if($emailNum>0)
	{
		echo  "The email you entered was already exists";
	}
	
	else if($userNum>0)
	{
		echo  "The username you entered was already exists";
	}
	
	
 

}

/*check whether the email already exists */
if(isset($_GET['checkEmail']))
{
	$email=$_POST['email'];
	$get=@mysql_query("select * from users where email='$email' and status=1");
	$num=@mysql_num_rows($get);
	if($num>0)
	{
	echo "Failed";	
	}
	else
	{
		echo "success";
	}
	
	
}

/*check whether the username already exists*/
if(isset($_GET['checkuserName']))
{
	$username=$_POST['username'];
	$get=@mysql_query("select * from users where username='$username' and status=1");
	$num=@mysql_num_rows($get);
	if($num>0)
	{
		echo "Failed";	
	}
	else
	{
		echo "success";
	}
	
}
/*Forgot password script*/
if(isset($_GET['forgot']))
{
    $email=$_POST['email_forgot'];
	$verify=@mysql_query("select * from users where email='$email'");
	$num=@mysql_num_rows($verify);
	if($num>0)
	{
		
		$dt=@mysql_fetch_array($verify);
		$first_name=$dt['first_name'];
		$last_name=$dt['last_name'];
		$fullname=$first_name." ".$last_name;
		$username=$dt['username'];
		$password=$dt['password'];
		
		$subject='Username/Password details for Underdog';
		$message = "Hi&nbsp;" . $fullname . "," . "<br/><br/>" . "Your login details for Underdog are ..<br><br><span><p>User Name : " . $username . "</p><p>Password :  " . $password . "</p><br/><br/>@" . date("Y") . " Underdog";
			
		$FromName='Underdog';
		
		/*$mail = new PHPMailer();$mail->IsSMTP();
		$mail->Host = 'albertatechworks.com';
		$mail->SMTPAuth = true;
		$mail->Username = 'aruna@albertatechworks.com'; // SMTP username
		$mail->Password = 'Aruna123456'; // SMTP password
		$mail->From = 'aruna@albertatechworks.com'; 
		$mail->FromName = 'Underdog';
		$mail->AddAddress($email,$username);
		$mail->WordWrap = 50;
		$mail->IsHTML(true);
		$mail->Subject = $subject;
		$mail->Body = $message;
		$mail->AltBody = $message;
		
		if(!$mail->Send())
		echo "Message could not be sent.";
		else*/
		echo "Your password has been sent to your registered email address";
		//echo "success";
	}
	else
	{
	   echo "The Email address you entered was not registered at Underdog.Please try again";
	}

}

/*create league*/
if(isset($_GET['create_league']))
{
    /*Declaring Post variables*/
    $league_name=$_POST['league_name'];
	$min_entries=$_POST['min_entries'];
	$max_entries=$_POST['max_entries'];
	$entry_fee=$_POST['entry_fee'];
	$tot_sizes=$_POST['tot_sizes'];
	$start_date=$_POST['start_date'];
	$end_date=$_POST['end_date'];
	$inputBody=$_POST['inputBody'];
	$added_user=$_SESSION['user_id'];
	$added_date=date("Y-m-d H:i:s");
    $status=$_GET['status'];
	 
	 
		  $ins="insert into league(`id`,`league_name`,`min_entries`,`max_entries`,`entry_fee`,`tot_sizes`,`start_date`,`end_date`,`inputBody`,`added_user`,`added_date`,`status`) values('','".$league_name."','".$min_entries."','".$max_entries."','".$entry_fee."','".$tot_sizes."','".$start_date."','".$end_date."','".$inputBody."','".$added_user."','".$added_date."','".$status."')";
		   
		$qry=@mysql_query($ins);
		 if($qry)
		 {
			 echo "success";
		 }
		 else
		 {
			echo  "Some thing went wrong.Please try again";
		 }
		

}

?>