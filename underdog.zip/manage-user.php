<?php
session_start();
include('db.php');

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Underdog -- App Management Sys</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/jquery.bxslider.css" rel="stylesheet">
	<link href="css/responsiveslides.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	
<header class="innerpage-header">
		<?php include('innerpage_header_admin.php'); ?>
	</header>
	
	
	<section class="inner-menu-admin">
		<?php include('inner_menu_admin.php');  ?>
	</section>
	
	<section class="tab-content-space">
		<div class="row">
			<div class="col-lg-12">
				<div class="form-label-head">User Management</div>
				<div class="form-box">
					<div class="top-search-bar clearfix">
						<div class="col-lg-6 text-left">
							<form class="form-inline" role="form">
								<div class="form-group small-width-admin">
								  <select class="form-control" id="sel1">
									<option>A</option>
									<option>B</option>
									<option>C</option>
									<option>4</option>
								  </select>
								</div>
								<div class="input-group">
								  <input type="text" class="form-control" placeholder="Search for...">
								  <span class="input-group-btn">
									<button class="btn btn-danger" type="button"><i class="fa fa-search" aria-hidden="true"></i></button>
								  </span>
								</div>
							</form>
						</div>
						<div class="col-lg-6 text-right">
							<button type="button" class="btn btn-success" data-toggle="modal" data-target="#invite-users"><i class="fa fa-users" aria-hidden="true"></i> Invite User's</button>
							<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#mail-users"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> Resend Mail</button>
							<button type="button" class="btn btn-danger"><i class="fa fa-download" aria-hidden="true"></i> Export CSV</button>
						</div>
					</div>
					<div class="admin-table table-responsive">
						<table class="table table-admin-style table-striped">
							<thead>
							  <tr>
								<th></th>
								<th>Username</th>
								<th>Email Address</th>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Address</th>
								<th>Status</th>
								<th>Actions</th>
							  </tr>
							</thead>
							<tbody>
							  <tr>
								<td class="select-all"><input type="checkbox" value=""></td>
								<td>gregorymkeller</td>
								<td>gregorymkeller@outlook.com</td>
								<td>Keller</td>
								<td>Gregor</td>
								<td><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit </p></td>
								<td><span class="active-user">Active</span></td>
								<td><a href="#" class="edit-btn"><span class="fa fa-pencil-square-o"></span></a> <a href="#" data-toggle="modal" data-target="#delete" class="delete-btn"><span class="fa fa-trash"></span></a></td>
							  </tr>
							  <tr>
								<td class="select-all"><input type="checkbox" value=""></td>
								<td>gregorymkeller</td>
								<td>gregorymkeller@outlook.com</td>
								<td>Keller</td>
								<td>Gregor</td>
								<td><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit </p></td>
								<td><span class="active-user">Active</span></td>
								<td><a href="#" class="edit-btn"><span class="fa fa-pencil-square-o"></span></a> <a href="#" data-toggle="modal" data-target="#delete" class="delete-btn"><span class="fa fa-trash"></span></a></td>
							  </tr>
							  <tr>
								<td class="select-all"><input type="checkbox" value=""></td>
								<td>gregorymkeller</td>
								<td>gregorymkeller@outlook.com</td>
								<td>Keller</td>
								<td>Gregor</td>
								<td><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit </p></td>
								<td><span class="active-user">Active</span></td>
								<td><a href="#" class="edit-btn"><span class="fa fa-pencil-square-o"></span></a> <a href="#" data-toggle="modal" data-target="#delete" class="delete-btn"><span class="fa fa-trash"></span></a></td>
							  </tr>
							  <tr>
								<td class="select-all"><input type="checkbox" value=""></td>
								<td>gregorymkeller</td>
								<td>gregorymkeller@outlook.com</td>
								<td>Keller</td>
								<td>Gregor</td>
								<td><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit </p></td>
								<td><span class="inactive-user">Inactive</span></td>
								<td><a href="#" class="edit-btn"><span class="fa fa-pencil-square-o"></span></a> <a href="#" data-toggle="modal" data-target="#delete" class="delete-btn"><span class="fa fa-trash"></span></a></td>
							  </tr>
							  <tr>
								<td class="select-all"><input type="checkbox" value=""></td>
								<td>gregorymkeller</td>
								<td>gregorymkeller@outlook.com</td>
								<td>Keller</td>
								<td>Gregor</td>
								<td><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit </p></td>
								<td><span class="active-user">Active</span></td>
								<td><a href="#" class="edit-btn"><span class="fa fa-pencil-square-o"></span></a> <a href="#" data-toggle="modal" data-target="#delete" class="delete-btn"><span class="fa fa-trash"></span></a></td>
							  </tr>
							  <tr>
								<td class="select-all"><input type="checkbox" value=""></td>
								<td>gregorymkeller</td>
								<td>gregorymkeller@outlook.com</td>
								<td>Keller</td>
								<td>Gregor</td>
								<td><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit </p></td>
								<td><span class="active-user">Active</span></td>
								<td><a href="#" class="edit-btn"><span class="fa fa-pencil-square-o"></span></a> <a href="#" data-toggle="modal" data-target="#delete" class="delete-btn"><span class="fa fa-trash"></span></a></td>
							  </tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="col-lg-12 text-center">
				<div class="pagination">
				  <a href="#">&laquo;</a>
				  <a href="#">1</a>
				  <a class="active" href="#">2</a>
				  <a href="#">3</a>
				  <a href="#">4</a>
				  <a href="#">5</a>
				  <a href="#">6</a>
				  <a href="#">&raquo;</a>
				</div>
			</div>
		</div>
	<section>
	
	
	

	
	<footer class="admin">
		<div class="container copy-rights">
			<div class="col-lg-12">
				<div class="copy-text text-center small-d">Copyright &copy; 2017 <a href="#">Underdog</a> All rights reserved</div>
			</div>
		</div>
	</footer>
	
	
	<!-- Alert Modal -->
	  <div class="modal fade" id="delete" role="dialog">
		<div class="modal-dialog">
		
		  <!-- Modal content-->
		  <div class="modal-content">
			<div class="modal-header alert-danger">
			  <button type="button" class="close" data-dismiss="modal">&times;</button>
			  <h4 class="modal-title">Attention</h4>
			</div>
			<div class="modal-body">
			    <div class="alert alert-danger">
				  <strong>Confirm!</strong> Are you sure want to delete user.
				</div>
			</div>
			<div class="modal-footer">
			  <button type="button" class="btn btn-warning" data-dismiss="modal">Yes</button> <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
			</div>
		  </div>
		  
		</div>
	  </div>
	  
	<!-- Invite User -->
	  <div class="modal fade" id="invite-users" role="dialog">
		<div class="modal-dialog">
		
		  <!-- Modal content-->
		  <div class="modal-content">
			<div class="modal-header ">
			  <button type="button" class="close" data-dismiss="modal">&times;</button>
			  
			</div>
			<div class="modal-body">
			    <h3 class="text-center black">Invite Friends. Get Premium for Free.</h3>
				<form class="register-form">
					<div class="form-label-head">Get Contacts</div>
					<div class="form-box">
						<p><span class="fa fa-smile-o"></span></p>
						<h3 class="text-center black">Invite your contacts from your Address Book</h3>
						<p><button class="btn facebook"><span class="fa fa-facebook-official"></span> Facebook</button><button class="btn gmail"><span class="fa fa-envelope"></span> Gmail</button><button class="btn twitter"><span class="fa fa-twitter-square"></span> Twitter</button></p>
						<p class="text-center"><input type="text" value="" placeholder="Email address"></p>
						<p class="text-center"><button class="btn btn-secondary customs-btn">Send Invitation</button></p>
					</div>
				</form>
			</div>
			<div class="modal-footer">
			  
			</div>
		  </div>
		  
		</div>
	  </div>
	  
	  <!-- Send Main User -->
	  <div class="modal fade" id="mail-users" role="dialog">
		<div class="modal-dialog">
		
		  <!-- Modal content-->
		  <div class="modal-content">
			<div class="modal-header alert-success">
			  <button type="button" class="close" data-dismiss="modal">&times;</button>
			  <h4 class="modal-title">Compose Mail</h4>
			</div>
			<div class="modal-body">
			    <form role="form" class="form-horizontal">
					<div class="form-group">
					  <label class="col-sm-2" for="inputTo">To</label>
					  <div class="col-sm-10"><input type="email" class="form-control" id="inputTo" placeholder="comma separated list of recipients"></div>
					</div>
					<div class="form-group">
					  <label class="col-sm-2" for="inputSubject">Subject</label>
					  <div class="col-sm-10"><input type="text" class="form-control" id="inputSubject" placeholder="subject"></div>
					</div>
					<div class="form-group">
					  <label class="col-sm-12" for="inputBody">Message</label>
					  <div class="col-sm-12"><textarea class="form-control" id="inputBody" rows="8"></textarea></div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button> 
				<button type="button" class="btn btn-warning pull-left">Save Draft</button>
				<button type="button" class="btn btn-primary pull-right">Send <i class="fa fa-arrow-circle-right fa-lg"></i></button>
			</div>
		  </div>
		  
		</div>
	  </div>
	
	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.bxslider.js"></script>
	
	<script src="js/responsiveslides.js"></script>
	<script>
		$('.bxslider').bxSlider({
		  mode: 'vertical',
		  auto: true,
		  slideMargin: 5,
		  pager:false
		});
	</script>
	<script>
	  $(function() {
		$(".rslides").responsiveSlides();
	  });
	</script>
  </body>
</html>