<div class="container copy-rights">
			<div class="col-lg-12">
				<div class="copy-text text-center small-d">Copyright &copy; 2017 <a href="#">Underdog</a> All rights reserved</div>
			</div>
		</div>