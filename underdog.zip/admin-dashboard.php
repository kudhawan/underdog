<?php
session_start();
include('db.php');

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Underdog -- App Management Sys</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/jquery.bxslider.css" rel="stylesheet">
	<link href="css/responsiveslides.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	
	<header class="innerpage-header">
		<?php include('innerpage_header_admin.php'); ?>
	</header>
	
	
	<section class="inner-menu-admin">
		<?php include('inner_menu_admin.php');  ?>
	</section>
	
	
	
	<section class="tab-content-space clearfix">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-4">
				<div class="form-label-head">Matches</div>
				<div class="form-box">
					<ul class="match-table">
						<li>
							<div class="match-name">Cincinnati Bengals <span>vs</span> Indianapolis Colts</div>
							<p>Running: <span class="fa fa-dot-circle-o"></span>0 -1 </p>
						</li>
						<li>
							<div class="match-name">Jacksonville Jaguars<span>vs</span> Philadelphia Eagles</div>
							<p><span class="fa fa-dot-circle-o"></span>4:00a Starts in 1h 36m</p>
						</li>
						<li>
							<div class="match-name">Atlanta Falcons<span>vs</span> New York Jets</div>
							<p><span class="fa fa-dot-circle-o"></span>4:00a Starts in 1h 36m</p>
						</li>
					</ul>
				</div>
				<div class="form-label-head top-space">League Type</div>
				<div class="form-box">
					<ul class="select-box">
						<li>
							<div class="form-group">
								<input type="checkbox" name="fancy-checkbox-default" id="fancy-checkbox-default" autocomplete="off" />
								<div class="btn-group">
									<label for="fancy-checkbox-default" class="btn btn-default">
										<span class="glyphicon glyphicon-ok"></span>
										<span> </span>
									</label>
									<label for="fancy-checkbox-default" class="btn btn-default active">
										Head to Head
									</label>
								</div>
							</div>
						</li>
						<li>
							<div class="form-group">
								<input type="checkbox" name="fancy-checkbox-warning" id="fancy-checkbox-warning" autocomplete="off" />
								<div class="btn-group">
									<label for="fancy-checkbox-warning" class="btn btn-warning">
										<span class="glyphicon glyphicon-ok"></span>
										<span> </span>
									</label>
									<label for="fancy-checkbox-warning" class="btn btn-warning active">
										Leagues
									</label>
								</div>
							</div>
						</li>
						<li>
							<div class="form-group">
								<input type="checkbox" name="fancy-checkbox-success" id="fancy-checkbox-success" autocomplete="off" />
								<div class="btn-group">
									<label for="fancy-checkbox-success" class="btn btn-success">
										<span class="glyphicon glyphicon-ok"></span>
										<span> </span>
									</label>
									<label for="fancy-checkbox-success" class="btn btn-success active">
										50 / 50
									</label>
								</div>
							</div>
						</li>
						<li>
							<div class="form-group">
								<input type="checkbox" name="fancy-checkbox-warning" id="fancy-checkbox-warning" autocomplete="off" />
								<div class="btn-group">
									<label for="fancy-checkbox-warning" class="btn btn-warning">
										<span class="glyphicon glyphicon-ok"></span>
										<span> </span>
									</label>
									<label for="fancy-checkbox-warning" class="btn btn-warning active">
										Tournaments
									</label>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
			
			<div class="col-lg-9 col-md-9 col-sm-8">
			
				<div class="form-label-head">Live Betting</div>
				<div class="form-box">
				
					<div class="row betting-bg">
						<div class="col-lg-4 col-md-3 col-sm-3">
							<div class="small-size">
								<div class="team-name"><img src="team-img/cin-logo.png" alt="">Cincinnati Bengals</div>
								<div class="score">0</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-6 col-sm-6">
							<div class="match-details">
								<div class="time" id="timer"></div>
								<div class="clearfix"><span class="pull-left redcard">1</span><span class="cards-pen">RED CARDS</span><span class="pull-right redcard">0</span></div>
								<div class="clearfix"><span class="pull-left yellowcard">0</span><span class="cards-pen">Yellow CARDS</span><span class="pull-right yellowcard">0</span></div>
								<div class="clearfix"><span class="pull-left corner">0</span><span class="cards-pen">Corners</span><span class="pull-right corner">0</span></div>
							</div>
						</div>
						<div class="col-lg-4 col-md-3 col-sm-3">
							<div class="small-size">
								<div class="team-name"><img src="team-img/colt-logo.png" alt="">Indianapolis Colts</div>
								<div class="score">1</div>
							</div>
						</div>
						<div class="col-lg-12">
							<div class="matches-bar">
								<ul class="bxslider">
									<li>Game Started</li>
									<li>Cincinnati Bengals Wins 1</li>
									<li>Indianapolis Colts in Corner 1</li>
									<li>XYZ</li>
								</ul>
							</div>
						</div>
					</div>
				
				</div>
				<div class="form-label-head top-space">Running League</div>
				<div class="form-box">
					<div class="lobby-table table-responsive">
						 <table class="table borderless lobby table-hover">
							<thead>
							  <tr>
								<th>League Name</th>
								<th>Entries</th>
								<th>Size</th>
								<th>Entry</th>
								<th>Prizes</th>
								<th>Start</th>
								<th></th>
							  </tr>
							</thead>
							<tbody>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.php">$3M NFL Sunday Million</a></td>
								<td>1377</td>
								<td>13793</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="#" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.php">$3M NFL Sunday Million</a></td>
								<td>10</td>
								<td>2777</td>
								<td>$200</td>
								<td>$5,000</td>
								<td>Sun 1pm</td>
								<td><a href="#" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.php">$12K NFL Bitz</a></td>
								<td>128</td>
								<td>11498</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="#" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.php">$12K NFL Bomb</a></td>
								<td>84</td>
								<td>13793</td>
								<td>$5</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="#" class="btn-com">Enter</a></td>
							  </tr>
							  <tr>
								<td><span class="fa fa-futbol-o"></span> <a href="live-betting.php">$10K NFL Punt</a></td>
								<td>1377</td>
								<td>13793</td>
								<td>$25</td>
								<td>$3,00,000</td>
								<td>Sun 1pm</td>
								<td><a href="#" class="btn-com">Enter</a></td>
							  </tr>
							</tbody>
						  </table>
					</div>
				</div>
			  </div>
			
		</div>
	</section>
	

	
<footer class="admin">
		<?php include('footer_admin.php'); ?>
	</footer>	
	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.bxslider.js"></script>
	
	<script src="js/responsiveslides.js"></script>
	<script>
		$('.bxslider').bxSlider({
		  mode: 'vertical',
		  auto: true,
		  slideMargin: 5,
		  pager:false
		});
	</script>
	<script>
	  $(function() {
		$(".rslides").responsiveSlides();
	  });
	</script>
  </body>
</html>