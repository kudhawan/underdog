<div class="row">
			<div class="col-lg-12">
				<ul class="nav nav-tabs">
					<li><a href="manage-league.php"><span class="fa fa-futbol-o white"></span> League</a></li>
					<li><a href="manage-betting.php"><span class="fa fa-trophy white"></span> Betting</a></li>
					<li><a href="manage-user.php"> <span class="fa fa-user white"></span> User</a></li>
					<!--<li><a href="manage-payment.html"> <span class="fa fa-money white"></span> Payment</a></li>-->
					<li><a href="manage-account.php"><span class="fa fa-cog white"></span> My Account</a></li>
				</ul>
			</div>
		</div>